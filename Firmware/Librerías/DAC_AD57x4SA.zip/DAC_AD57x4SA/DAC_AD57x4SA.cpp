// ----------------------------------------------------------------------------
//DAC_AD57x4.h
//
// Provides an SPI based interface to the
//
// Author: Steve Sawtelle - based on TLE7232 by Peter Polidoro
// 20180410 sws
//- move to use SPI_SETTINGS

// 20151116 sws
//  - use a define for SPI_MODE
//  - use SPI_MODE 2 not 1
// -------------------------------------------------------------

#if defined(ARDUINO) && ARDUINO >= 100
#include "Arduino.h"
#else
#include "WProgram.h"
#endif

#include <SPI.h>

#include "DAC_AD57x4SA.h"


// CPOL = 0, clock rests low
// CPHA = 1, capture data on falling edge

//#define AD57X4_MODE SPI_MODE1
//#define AD57X4_CLK SPI_CLOCK_DIV16

//---------- constructor  ---------------------------------------

DAC_AD57x4SA::DAC_AD57x4SA()
{

}

// - private
SPISettings DAC_AD57x4_SPI(4000000, MSBFIRST, SPI_MODE1);


//---------- public  ------------------------------------
uint16_t DAC_AD57x4SA::begin(uint8_t cspin)
{
        _csPin = cspin;
	    pinMode(_csPin, OUTPUT);
	    digitalWrite(_csPin, HIGH);
	
//    noInterrupts(); // ATOMIC_BLOCK(ATOMIC_RESTORESTATE)

         //SPI.setDataMode(AD57X4_MODE);  // set proper mode,
         //SPI.setClockDivider(AD57X4_CLK);  // set clock
		 SPI.beginTransaction(DAC_AD57x4_SPI);
         // set output ranges to +/-10V
         for( uint8_t  ch = 0; ch < 4; ch++ )
         {
            digitalWrite(_csPin, LOW);
            SPI.transfer(0x08 | ch);
            SPI.transfer(0x00);
            SPI.transfer(0x04);
            digitalWrite(_csPin, HIGH);
         }


         // Control register = 0001 1001 0000 0000 0000 1101
         // no SDO, thermal shutdown, overcuurent protect, default to mid scale
         digitalWrite(_csPin, LOW);
         SPI.transfer(0x19);
         SPI.transfer(0x00);
         SPI.transfer(0x0d);
         digitalWrite(_csPin, HIGH);
         // Power Control register = 0001 0000 0000 0000 0001 1111
         //  enable all DACs
         digitalWrite(_csPin, LOW);
         SPI.transfer(0x10);
         SPI.transfer(0x00);
         SPI.transfer(0x1f);
         digitalWrite(_csPin, HIGH);
         SPI.endTransaction();
 //      interrupts();

   return 0;
}



void DAC_AD57x4SA::setRange( uint8_t ch, uint8_t range)
{
    if( (ch == 0 ) || ( ch > 4 )) return;
    ch--;

// noInterrupts(); // ATOMIC_BLOCK(ATOMIC_RESTORESTATE)
//  {
      //SPI.setDataMode(AD57X4_MODE);  // set proper mode,
     // SPI.setClockDivider(AD57X4_CLK);  // set clock
	  SPI.beginTransaction(DAC_AD57x4_SPI);
      digitalWrite(_csPin, LOW);
      SPI.transfer(0x08 | ch);
      SPI.transfer(0x00);
      SPI.transfer(range);
      digitalWrite(_csPin, HIGH);
	  SPI.endTransaction();
 //  }
 //  interrupts();
}


uint8_t DAC_AD57x4SA::getRange( uint8_t ch)  // NOT DONE>>>>>
{
uint8_t range;
   if( (ch == 0 ) || ( ch > 4 )) return 0xff;
   ch--;

//   noInterrupts(); //ATOMIC_BLOCK(ATOMIC_RESTORESTATE)
 //  {
       //SPI.setDataMode(AD57X4_MODE);  // set proper mode,
       //SPI.setClockDivider(AD57X4_CLK);  // set clock
	   SPI.beginTransaction(DAC_AD57x4_SPI); 
       digitalWrite(_csPin, LOW);
       SPI.transfer(0x88 | ch);
       range = SPI.transfer(0x00);
       SPI.transfer(range);
       digitalWrite(_csPin, HIGH);
	   SPI.endTransaction();
 //   }
 //  interrupts();
   return 0;
}


uint8_t DAC_AD57x4SA::write(uint8_t ch, int16_t data )
{
  if( (ch == 0 ) || ( ch > 4 )) return 0xff;
  ch--;


 // ATOMIC_BLOCK(ATOMIC_RESTORESTATE)
//  noInterrupts();
//  {
      //SPI.setDataMode(AD57X4_MODE);  // set proper mode, clk idle hi, edge = 0 => mode = 2
      //SPI.setClockDivider(AD57X4_CLK);  // set clock
	  SPI.beginTransaction(DAC_AD57x4_SPI); 
      digitalWrite(_csPin, LOW);
      SPI.transfer(ch);
      SPI.transfer(data >> 8);
      SPI.transfer(data & 0xff);
      digitalWrite(_csPin, HIGH);
	  SPI.endTransaction();
//  } // end atomic block
//  interrupts();

  return 0;

}










