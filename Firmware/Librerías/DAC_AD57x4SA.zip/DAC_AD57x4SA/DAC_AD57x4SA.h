// ----------------------------------------------------------------------------
//AD57x4_-SA.h
//
// stand alone (not BCSIII) version
//
// Author: SWS based on code by Peter Polidoro
// ----------------------------------------------------------------------------

#ifndef DAC_AD57x4_H_
#define DAC_AD57x4_H_

#if defined(ARDUINO) && ARDUINO >= 100
#include "Arduino.h"
#else
#include "WProgram.h"
#endif

class DAC_AD57x4SA
{
public:

  DAC_AD57x4SA(void);
  uint16_t begin(uint8_t ch);
  void setRange(uint8_t channel, uint8_t range);
  uint8_t getRange(uint8_t channel);
  uint8_t write(uint8_t channel, int16_t val);


// range constants
  #define DAC_BIP10  0x04  // +/-10V
  #define DAC_BIP5   0x03  // +/-5V
  #define DAC_UNI5   0x00 //   +5V
  #define DAC_UNI10  0x01 //  +10V

  #define DAC_AD57x4_ID 2  // ordinal value for this panel's ID_SENSE
  

private:
   int _csPin;  

};

#endif // DAC_AD57x4
